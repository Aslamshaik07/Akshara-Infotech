import { useState, useEffect } from 'react';
import LoadingScreen from './components/LoadingScreen';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import CoursesSection from './components/CoursesSection';
import PortfolioSection from './components/PortfolioSection';
import PopularCoursesSection from './components/PopularCoursesSection';
import ReviewsSection from './components/ReviewsSection';
import FAQSection from './components/FAQSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import CustomCursor from './components/CustomCursor';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
  }, []);

  const handleLoadingComplete = () => {
    setIsLoading(false);
    document.body.style.overflow = 'auto';
  };

  return (
    <>
      {isLoading && <LoadingScreen onComplete={handleLoadingComplete} />}

      {!isLoading && (
        <div className="min-h-screen bg-white">
          <CustomCursor />
          <Navbar />
          <HeroSection />
          <AboutSection />
          <CoursesSection />
          <PortfolioSection />
          <PopularCoursesSection />
          <ReviewsSection />
          <FAQSection />
          <ContactSection />
          <Footer />
          <WhatsAppButton />
        </div>
      )}
    </>
  );
}

export default App;
