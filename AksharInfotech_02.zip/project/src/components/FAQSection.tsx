import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'What courses does Akshara Infotech offer?',
      answer: 'We offer a wide range of IT courses including Microsoft 365, Azure, AWS, Linux, Data Science, Power BI, SAP, DevOps, VMware, Data Engineering, CCNA, Python, and Windows Server administration.',
    },
    {
      question: 'What is the duration of the courses?',
      answer: 'Course duration varies from 4 to 12 weeks depending on the program. Each course includes comprehensive theory, hands-on labs, real-world projects, and certification preparation.',
    },
    {
      question: 'Do you provide placement assistance?',
      answer: 'Yes, we provide 100% placement assistance to all our students. We have tie-ups with leading IT companies and conduct regular placement drives. Our dedicated placement team helps with resume building, interview preparation, and job referrals.',
    },
    {
      question: 'Are the courses suitable for beginners?',
      answer: 'Absolutely! Our courses are designed for all levels - from beginners to advanced professionals. We start with fundamentals and gradually progress to advanced topics with hands-on practice.',
    },
    {
      question: 'What are the class timings?',
      answer: 'We offer flexible batch timings including weekday morning, afternoon, evening batches, and weekend batches to accommodate working professionals and students.',
    },
    {
      question: 'Will I get a certificate after course completion?',
      answer: 'Yes, you will receive a course completion certificate from Akshara Infotech. Additionally, we prepare you for industry-recognized certifications from Microsoft, AWS, Cisco, and other vendors.',
    },
    {
      question: 'What is the fee structure?',
      answer: 'Course fees vary depending on the program. We offer competitive pricing with flexible payment options and EMI facilities. Please contact us for detailed fee information.',
    },
    {
      question: 'Do you provide online or classroom training?',
      answer: 'We provide both online and classroom training options. Our online sessions are interactive with live instructor-led training, and our classroom training features state-of-the-art labs.',
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-5xl font-bold text-gray-900 mb-4">
            Frequently Asked Questions
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8" />
          <p className="text-xl text-gray-600">
            Find answers to common questions about our courses and services
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="border border-gray-200 rounded-2xl overflow-hidden hover:shadow-lg transition-all duration-300 animate-slide-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left bg-white hover:bg-gray-50 transition-colors duration-200"
              >
                <span className="text-lg font-semibold text-gray-900 pr-4">
                  {faq.question}
                </span>
                <ChevronDown
                  className={`flex-shrink-0 w-6 h-6 text-blue-600 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="p-6 pt-0 text-gray-600 leading-relaxed">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
