import { useEffect, useRef } from 'react';

export default function CoursesSection() {
  const scrollRef = useRef<HTMLDivElement>(null);

  const getCourseContent = (name: string) => {
    const courseData: Record<string, { icon: string; bgGradient: string; accentColor: string }> = {
      'Windows Server': {
        icon: '🪟',
        bgGradient: 'from-blue-500 to-blue-600',
        accentColor: 'text-blue-600',
      },
      'Microsoft 365': {
        icon: '☁️',
        bgGradient: 'from-orange-500 to-orange-600',
        accentColor: 'text-orange-600',
      },
      Azure: {
        icon: '☁️',
        bgGradient: 'from-blue-600 to-blue-700',
        accentColor: 'text-blue-700',
      },
      AWS: {
        icon: '☁️',
        bgGradient: 'from-yellow-500 to-orange-500',
        accentColor: 'text-orange-500',
      },
      Linux: {
        icon: '🐧',
        bgGradient: 'from-gray-700 to-gray-800',
        accentColor: 'text-gray-800',
      },
      'Data Science': {
        icon: '📊',
        bgGradient: 'from-purple-500 to-purple-600',
        accentColor: 'text-purple-600',
      },
      'Power BI': {
        icon: '📈',
        bgGradient: 'from-yellow-500 to-yellow-600',
        accentColor: 'text-yellow-600',
      },
      SAP: {
        icon: '🏢',
        bgGradient: 'from-blue-500 to-blue-700',
        accentColor: 'text-blue-700',
      },
      DevOps: {
        icon: '⚙️',
        bgGradient: 'from-green-500 to-green-600',
        accentColor: 'text-green-600',
      },
      VMware: {
        icon: '🖥️',
        bgGradient: 'from-gray-600 to-gray-700',
        accentColor: 'text-gray-700',
      },
      'Data Engineering': {
        icon: '🔧',
        bgGradient: 'from-blue-700 to-blue-800',
        accentColor: 'text-blue-800',
      },
      CCNA: {
        icon: '🌐',
        bgGradient: 'from-cyan-500 to-cyan-600',
        accentColor: 'text-cyan-600',
      },
      Python: {
        icon: '🐍',
        bgGradient: 'from-blue-500 to-yellow-500',
        accentColor: 'text-blue-500',
      },
    };
    return courseData[name] || { icon: '📚', bgGradient: 'from-gray-500 to-gray-600', accentColor: 'text-gray-600' };
  };

  const courses = [
    { name: 'Windows Server' },
    { name: 'Microsoft 365' },
    { name: 'Azure' },
    { name: 'AWS' },
    { name: 'Linux' },
    { name: 'Data Science' },
    { name: 'Power BI' },
    { name: 'SAP' },
    { name: 'DevOps' },
    { name: 'VMware' },
    { name: 'Data Engineering' },
    { name: 'CCNA' },
    { name: 'Python' },
  ];

  const allCourses = [...courses, ...courses];

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    let scrollPosition = 0;
    const scroll = () => {
      scrollPosition += 1;
      if (scrollPosition >= scrollContainer.scrollWidth / 2) {
        scrollPosition = 0;
      }
      scrollContainer.scrollLeft = scrollPosition;
    };

    const intervalId = setInterval(scroll, 30);
    return () => clearInterval(intervalId);
  }, []);

  return (
    <section id="courses" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="text-center animate-fade-in">
          <h2 className="text-5xl font-bold text-gray-900 mb-4">Our Courses</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8" />
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our comprehensive range of industry-leading IT courses designed to boost your
            career in technology. From cloud computing to data science, we've got you covered.
          </p>
        </div>
      </div>

      <div className="relative overflow-hidden">
        <div
          ref={scrollRef}
          className="flex gap-8 overflow-x-hidden pb-4"
          style={{ scrollBehavior: 'auto' }}
        >
          {allCourses.map((course, index) => {
            const { icon, bgGradient } = getCourseContent(course.name);

            const gradientClasses: Record<string, string> = {
              'from-blue-500 to-blue-600': 'bg-gradient-to-br from-blue-500 to-blue-600',
              'from-orange-500 to-orange-600': 'bg-gradient-to-br from-orange-500 to-orange-600',
              'from-blue-600 to-blue-700': 'bg-gradient-to-br from-blue-600 to-blue-700',
              'from-yellow-500 to-orange-500': 'bg-gradient-to-br from-yellow-500 to-orange-500',
              'from-gray-700 to-gray-800': 'bg-gradient-to-br from-gray-700 to-gray-800',
              'from-purple-500 to-purple-600': 'bg-gradient-to-br from-purple-500 to-purple-600',
              'from-yellow-500 to-yellow-600': 'bg-gradient-to-br from-yellow-500 to-yellow-600',
              'from-blue-500 to-blue-700': 'bg-gradient-to-br from-blue-500 to-blue-700',
              'from-green-500 to-green-600': 'bg-gradient-to-br from-green-500 to-green-600',
              'from-gray-600 to-gray-700': 'bg-gradient-to-br from-gray-600 to-gray-700',
              'from-blue-700 to-blue-800': 'bg-gradient-to-br from-blue-700 to-blue-800',
              'from-cyan-500 to-cyan-600': 'bg-gradient-to-br from-cyan-500 to-cyan-600',
              'from-blue-500 to-yellow-500': 'bg-gradient-to-br from-blue-500 to-yellow-500',
            };

            return (
              <div
                key={index}
                className={`flex-shrink-0 w-80 h-80 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 flex flex-col items-center justify-center text-white p-8 cursor-pointer relative overflow-hidden group ${gradientClasses[bgGradient] || 'bg-gradient-to-br from-gray-500 to-gray-600'}`}
              >
                <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-20 transition-opacity duration-300" />

                <div className="relative z-10 flex flex-col items-center justify-center h-full w-full">
                  <div className="text-9xl mb-4 animate-bounce-slow drop-shadow-lg">{icon}</div>
                  <h3 className="text-3xl font-bold text-center drop-shadow-lg">{course.name}</h3>
                </div>

                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center bg-black/50 rounded-3xl">
                  <span className="text-white text-center font-semibold text-lg px-4">Professional Certification</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300">
            <h3 className="text-4xl font-bold text-blue-600 mb-2">13+</h3>
            <p className="text-gray-600 text-lg">Professional Courses</p>
          </div>
          <div className="p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300">
            <h3 className="text-4xl font-bold text-blue-600 mb-2">100%</h3>
            <p className="text-gray-600 text-lg">Practical Training</p>
          </div>
          <div className="p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300">
            <h3 className="text-4xl font-bold text-blue-600 mb-2">Expert</h3>
            <p className="text-gray-600 text-lg">Industry Trainers</p>
          </div>
        </div>
      </div>
    </section>
  );
}
