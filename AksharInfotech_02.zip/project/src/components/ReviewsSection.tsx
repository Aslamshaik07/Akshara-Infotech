import { Star, Quote } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function ReviewsSection() {
  const [activeIndex, setActiveIndex] = useState(0);

  const reviews = [
    {
      name: 'Rajesh Kumar',
      course: 'Azure Cloud Engineer',
      rating: 5,
      text: 'Excellent training experience! The instructors are highly knowledgeable and the hands-on labs helped me understand Azure deeply. Got placed within 2 months of completion.',
      image: '👨‍💼',
    },
    {
      name: 'Priya Sharma',
      course: 'Microsoft 365 Administrator',
      rating: 5,
      text: 'Akshara Infotech transformed my career. The M365 course was comprehensive and practical. The trainers gave individual attention and cleared all my doubts.',
      image: '👩‍💼',
    },
    {
      name: 'Sanjay Reddy',
      course: 'AWS Solutions Architect',
      rating: 5,
      text: 'Best decision I made was joining Akshara Infotech. The AWS course content is up-to-date with industry standards. Highly recommend for anyone looking to build a career in cloud.',
      image: '👨‍💻',
    },
    {
      name: 'Anjali Patel',
      course: 'Data Science & Python',
      rating: 5,
      text: 'Outstanding training program! The Data Science course covered everything from basics to advanced topics. The real-world projects helped me build a strong portfolio.',
      image: '👩‍🔬',
    },
    {
      name: 'Vikram Singh',
      course: 'DevOps Engineer',
      rating: 5,
      text: 'Professional environment and excellent teaching methodology. The DevOps training gave me the skills I needed to advance in my career. Thank you Akshara Infotech!',
      image: '👨‍🔧',
    },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % reviews.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [reviews.length]);

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-5xl font-bold text-gray-900 mb-4">Student Reviews</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8" />
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Hear what our students have to say about their learning experience
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div className="overflow-hidden">
            {reviews.map((review, index) => (
              <div
                key={index}
                className={`transition-all duration-500 ${
                  index === activeIndex ? 'opacity-100 scale-100' : 'opacity-0 scale-95 absolute inset-0'
                }`}
              >
                <div className="bg-white rounded-3xl shadow-2xl p-12 relative">
                  <Quote className="absolute top-8 left-8 w-16 h-16 text-blue-200" />

                  <div className="flex flex-col items-center text-center relative z-10">
                    <div className="text-7xl mb-6">{review.image}</div>

                    <div className="flex mb-4">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>

                    <p className="text-xl text-gray-700 mb-6 leading-relaxed italic">
                      "{review.text}"
                    </p>

                    <h4 className="text-2xl font-bold text-gray-900 mb-2">{review.name}</h4>
                    <p className="text-blue-600 font-semibold">{review.course}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center gap-3 mt-8">
            {reviews.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === activeIndex ? 'bg-blue-600 w-12' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="p-6 bg-white rounded-2xl shadow-lg">
            <h3 className="text-4xl font-bold text-blue-600 mb-2">4.9/5</h3>
            <p className="text-gray-600">Average Rating</p>
          </div>
          <div className="p-6 bg-white rounded-2xl shadow-lg">
            <h3 className="text-4xl font-bold text-blue-600 mb-2">500+</h3>
            <p className="text-gray-600">Reviews</p>
          </div>
          <div className="p-6 bg-white rounded-2xl shadow-lg">
            <h3 className="text-4xl font-bold text-blue-600 mb-2">98%</h3>
            <p className="text-gray-600">Satisfaction</p>
          </div>
          <div className="p-6 bg-white rounded-2xl shadow-lg">
            <h3 className="text-4xl font-bold text-blue-600 mb-2">1000+</h3>
            <p className="text-gray-600">Graduates</p>
          </div>
        </div>
      </div>
    </section>
  );
}
