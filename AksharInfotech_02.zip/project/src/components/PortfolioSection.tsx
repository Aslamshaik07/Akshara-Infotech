import { Target, Users, Award, TrendingUp } from 'lucide-react';

export default function PortfolioSection() {
  return (
    <section id="portfolio" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-5xl font-bold text-gray-900 mb-4">Portfolio</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="animate-slide-left">
            <img
              src="/logo.jpg"
              alt="Akshara Infotech"
              className="rounded-3xl shadow-2xl hover:scale-105 transition-transform duration-500"
            />
          </div>

          <div className="animate-slide-right">
            <h3 className="text-4xl font-bold text-gray-900 mb-6">
              About Akshara Infotech
            </h3>
            <p className="text-lg text-gray-600 leading-relaxed mb-6">
              Akshara Infotech stands as a beacon of excellence in IT education, committed to
              transforming aspiring professionals into industry-ready experts. With state-of-the-art
              infrastructure and a curriculum designed by industry veterans, we ensure that our
              students receive the most relevant and practical training.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed mb-6">
              Our training methodology combines theoretical knowledge with hands-on practical
              sessions, real-world projects, and industry case studies. We maintain strong
              partnerships with leading tech companies to provide our students with placement
              opportunities and industry exposure.
            </p>
            <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="flex items-center gap-3">
                <Target className="w-8 h-8 text-blue-600" />
                <span className="text-gray-700 font-semibold">Goal-Oriented Training</span>
              </div>
              <div className="flex items-center gap-3">
                <Award className="w-8 h-8 text-blue-600" />
                <span className="text-gray-700 font-semibold">Certified Programs</span>
              </div>
              <div className="flex items-center gap-3">
                <Users className="w-8 h-8 text-blue-600" />
                <span className="text-gray-700 font-semibold">Expert Mentors</span>
              </div>
              <div className="flex items-center gap-3">
                <TrendingUp className="w-8 h-8 text-blue-600" />
                <span className="text-gray-700 font-semibold">Career Growth</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-3xl p-12 text-white">
          <div className="text-center mb-12">
            <h3 className="text-4xl font-bold mb-4">Build Your Career with Akshara Infotech</h3>
            <p className="text-xl max-w-3xl mx-auto">
              Join thousands of successful IT professionals who started their journey with us.
              We're not just a training institute; we're your partner in career success.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="animate-count-up">
              <h4 className="text-6xl font-bold mb-2">500+</h4>
              <p className="text-xl">Happy Students</p>
            </div>
            <div className="animate-count-up animation-delay-2000">
              <h4 className="text-6xl font-bold mb-2">95%</h4>
              <p className="text-xl">Placement Rate</p>
            </div>
            <div className="animate-count-up animation-delay-4000">
              <h4 className="text-6xl font-bold mb-2">50+</h4>
              <p className="text-xl">Corporate Partners</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
