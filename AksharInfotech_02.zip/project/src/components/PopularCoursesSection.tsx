import { Cloud, Database, LineChart, Shield } from 'lucide-react';

export default function PopularCoursesSection() {
  const popularCourses = [
    {
      title: 'Microsoft 365',
      description: 'Master cloud productivity with M365 suite including Teams, SharePoint, Exchange, and Power Platform.',
      icon: <Cloud className="w-16 h-16 text-orange-500" />,
      duration: '6 Weeks',
      level: 'Beginner to Advanced',
      color: 'from-orange-50 to-orange-100',
    },
    {
      title: 'Microsoft Azure',
      description: 'Become an Azure expert with comprehensive training in cloud infrastructure, security, and DevOps.',
      icon: <Cloud className="w-16 h-16 text-blue-600" />,
      duration: '8 Weeks',
      level: 'Intermediate to Advanced',
      color: 'from-blue-50 to-blue-100',
    },
    {
      title: 'AWS Cloud',
      description: 'Learn Amazon Web Services from scratch to advanced level with hands-on labs and real-world projects.',
      icon: <Database className="w-16 h-16 text-yellow-600" />,
      duration: '8 Weeks',
      level: 'Beginner to Advanced',
      color: 'from-yellow-50 to-yellow-100',
    },
    {
      title: 'Power BI',
      description: 'Transform data into insights with Power BI. Learn data visualization and business intelligence.',
      icon: <LineChart className="w-16 h-16 text-yellow-500" />,
      duration: '4 Weeks',
      level: 'Beginner to Intermediate',
      color: 'from-yellow-50 to-amber-100',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-5xl font-bold text-gray-900 mb-4">
            Akshara Infotech Popular Courses
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8" />
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our most sought-after courses that are shaping the future of IT professionals
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {popularCourses.map((course, index) => (
            <div
              key={index}
              className={`bg-gradient-to-br ${course.color} rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 animate-slide-up`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start gap-6">
                <div className="flex-shrink-0 p-4 bg-white rounded-2xl shadow-md">
                  {course.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-3xl font-bold text-gray-900 mb-3">{course.title}</h3>
                  <p className="text-gray-700 mb-4 leading-relaxed">{course.description}</p>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full">
                      <Shield className="w-4 h-4 text-blue-600" />
                      <span className="font-semibold text-gray-700">{course.level}</span>
                    </div>
                    <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full">
                      <span className="font-semibold text-gray-700">{course.duration}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
