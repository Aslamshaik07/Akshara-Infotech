import { ChevronRight } from 'lucide-react';

export default function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-50 via-white to-blue-50 pt-20">
      <div className="absolute inset-0 bg-grid-pattern opacity-5" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="animate-fade-in">
          <h1 className="text-6xl md:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-blue-800 mb-6 animate-slide-up">
            Akshara Infotech
          </h1>

          <div className="text-2xl md:text-4xl text-gray-700 mb-8 h-20 flex items-center justify-center">
            <p className="animate-typing overflow-hidden whitespace-nowrap border-r-4 border-blue-600 pr-2">
              Empowering Careers Through Technology
            </p>
          </div>

          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto animate-slide-up-delay">
            Transform your future with industry-leading IT courses and certifications
          </p>

          <button className="group bg-gradient-to-r from-blue-600 to-blue-700 text-white px-10 py-4 rounded-full text-xl font-semibold hover:shadow-2xl transition-all duration-300 hover:scale-110 animate-bounce-slow inline-flex items-center gap-2">
            Join Now
            <ChevronRight className="group-hover:translate-x-2 transition-transform duration-300" />
          </button>
        </div>

        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob" />
        <div className="absolute top-40 right-10 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000" />
        <div className="absolute bottom-20 left-1/2 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000" />
      </div>
    </section>
  );
}
