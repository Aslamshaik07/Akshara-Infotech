import { Award, Users, BookOpen, TrendingUp } from 'lucide-react';

export default function AboutSection() {
  const features = [
    {
      icon: <Award className="w-12 h-12 text-blue-600" />,
      title: 'Industry Certified',
      description: 'Get certified with globally recognized IT certifications',
    },
    {
      icon: <Users className="w-12 h-12 text-blue-600" />,
      title: 'Expert Trainers',
      description: 'Learn from industry professionals with years of experience',
    },
    {
      icon: <BookOpen className="w-12 h-12 text-blue-600" />,
      title: 'Comprehensive Courses',
      description: 'Wide range of courses covering latest technologies',
    },
    {
      icon: <TrendingUp className="w-12 h-12 text-blue-600" />,
      title: 'Career Growth',
      description: 'Build skills that accelerate your career in IT',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-5xl font-bold text-gray-900 mb-4">About Us</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8" />
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Akshara Infotech is a premier IT training institute dedicated to empowering individuals
            with cutting-edge technology skills. We offer comprehensive training programs in Cloud
            Computing, Data Science, DevOps, Networking, and various other IT domains.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-6 rounded-2xl bg-gradient-to-br from-blue-50 to-white border border-blue-100 hover:shadow-2xl transition-all duration-300 hover:scale-105 animate-slide-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-3xl p-12 text-white text-center">
          <h3 className="text-4xl font-bold mb-4">Our Mission</h3>
          <p className="text-xl max-w-4xl mx-auto leading-relaxed">
            To bridge the gap between academic learning and industry requirements by providing
            world-class training, hands-on experience, and career support to help students achieve
            their professional goals in the rapidly evolving IT industry.
          </p>
        </div>
      </div>
    </section>
  );
}
